const Estudiante = require("../Models/Estudiante.js");

let estudiantes = [
  new Estudiante(1, "L001", "Ana", "Gomez", 21, "Ingenieria en Sistemas"),
  new Estudiante(2, "L002", "Luis", "Perez", 23, "Contador Publico"),
];

let siguienteId = 3;

class EstudiantesController {
  // GET /listar  (?id=  y/o  ?carrera=)
  consultar(req, res) {
    const { id, carrera } = req.query;

    // Ejercicio 1 (parte de consulta): si viene id, buscamos ese puntual
    if (id) {
      const estudiante = estudiantes.find((e) => e.id === Number(id));
      if (!estudiante) {
        return res.status(404).json({
          mensaje: `No se encontro un estudiante con id ${id}`,
        });
      }
      return res.json({
        mensaje: "consulta estudiante",
        data: estudiante,
      });
    }

    // Ejercicio 2: si viene carrera (y no id), filtramos por carrera
    if (carrera) {
      const filtrados = estudiantes.filter(
        (e) => e.carrera.toLowerCase() === carrera.toLowerCase()
      );
      return res.json({
        mensaje: `consulta estudiantes por carrera: ${carrera}`,
        data: filtrados,
      });
    }

    // Si no vino ni id ni carrera, devolvemos todos
    res.json({
      mensaje: "consulta estudiantes",
      data: estudiantes,
    });
  }

  // POST /alta
  ingresar(req, res) {
    const { legajo, nombre, apellido, edad, carrera } = req.body;

    if (!nombre || !apellido) {
      return res.status(400).json({
        mensaje: "nombre y apellido son obligatorios",
      });
    }

    const nuevoEstudiante = new Estudiante(
      siguienteId,
      legajo,
      nombre,
      apellido,
      edad,
      carrera
    );

    estudiantes.push(nuevoEstudiante);
    siguienteId++;

    res.status(201).json({
      mensaje: "ingreso estudiantes",
      data: nuevoEstudiante,
    });
  }

  // PUT /modificar
  actualizar(req, res) {
    const { id, legajo, nombre, apellido, edad, carrera } = req.body;

    if (!id) {
      return res.status(400).json({
        mensaje: "el id es obligatorio para modificar un estudiante",
      });
    }

    const estudiante = estudiantes.find((e) => e.id === Number(id));

    if (!estudiante) {
      return res.status(404).json({
        mensaje: `No se encontro un estudiante con id ${id}`,
      });
    }

    if (legajo !== undefined) estudiante.legajo = legajo;
    if (nombre !== undefined) estudiante.nombre = nombre;
    if (apellido !== undefined) estudiante.apellido = apellido;
    if (edad !== undefined) estudiante.edad = edad;
    if (carrera !== undefined) estudiante.carrera = carrera;

    res.json({
      mensaje: "modificacion estudiantes",
      data: estudiante,
    });
  }

  // DELETE /eliminar
  borrar(req, res) {
    const { id } = req.body;

    if (!id) {
      return res.status(400).json({
        mensaje: "el id es obligatorio para eliminar un estudiante",
      });
    }

    const existe = estudiantes.some((e) => e.id === Number(id));

    if (!existe) {
      return res.status(404).json({
        mensaje: `No se encontro un estudiante con id ${id}`,
      });
    }

    estudiantes = estudiantes.filter((e) => e.id !== Number(id));

    res.json({
      mensaje: "eliminacion estudiantes",
    });
  }
}

module.exports = new EstudiantesController();

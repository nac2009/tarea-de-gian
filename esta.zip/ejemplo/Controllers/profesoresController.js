const Profesor = require("../Models/Profesor.js");

let profesores = [
  new Profesor(1, "P001", "Marta", "Suarez", "Programacion I"),
  new Profesor(2, "P002", "Jorge", "Lopez", "Base de Datos"),
];

let siguienteId = 3;

class ProfesoresController {
  // GET /listar  (?id=  y/o  ?materia=)
  consultar(req, res) {
    const { id, materia } = req.query;

    if (id) {
      const profesor = profesores.find((p) => p.id === Number(id));
      if (!profesor) {
        return res.status(404).json({
          mensaje: `No se encontro un profesor con id ${id}`,
        });
      }
      return res.json({
        mensaje: "consulta profesor",
        data: profesor,
      });
    }

    if (materia) {
      const filtrados = profesores.filter(
        (p) => p.materia.toLowerCase() === materia.toLowerCase()
      );
      return res.json({
        mensaje: `consulta profesores por materia: ${materia}`,
        data: filtrados,
      });
    }

    res.json({
      mensaje: "consulta profesores",
      data: profesores,
    });
  }

  // POST /alta
  ingresar(req, res) {
    const { legajo, nombre, apellido, materia } = req.body;

    if (!nombre || !apellido) {
      return res.status(400).json({
        mensaje: "nombre y apellido son obligatorios",
      });
    }

    const nuevoProfesor = new Profesor(
      siguienteId,
      legajo,
      nombre,
      apellido,
      materia
    );

    profesores.push(nuevoProfesor);
    siguienteId++;

    res.status(201).json({
      mensaje: "ingreso profesores",
      data: nuevoProfesor,
    });
  }

  // PUT /modificar
  actualizar(req, res) {
    const { id, legajo, nombre, apellido, materia } = req.body;

    if (!id) {
      return res.status(400).json({
        mensaje: "el id es obligatorio para modificar un profesor",
      });
    }

    const profesor = profesores.find((p) => p.id === Number(id));

    if (!profesor) {
      return res.status(404).json({
        mensaje: `No se encontro un profesor con id ${id}`,
      });
    }

    if (legajo !== undefined) profesor.legajo = legajo;
    if (nombre !== undefined) profesor.nombre = nombre;
    if (apellido !== undefined) profesor.apellido = apellido;
    if (materia !== undefined) profesor.materia = materia;

    res.json({
      mensaje: "modificacion profesores",
      data: profesor,
    });
  }

  // DELETE /eliminar
  borrar(req, res) {
    const { id } = req.body;

    if (!id) {
      return res.status(400).json({
        mensaje: "el id es obligatorio para eliminar un profesor",
      });
    }

    const existe = profesores.some((p) => p.id === Number(id));

    if (!existe) {
      return res.status(404).json({
        mensaje: `No se encontro un profesor con id ${id}`,
      });
    }

    profesores = profesores.filter((p) => p.id !== Number(id));

    res.json({
      mensaje: "eliminacion profesores",
    });
  }
}

module.exports = new ProfesoresController();

class Profesor {
  constructor(id, legajo, nombre, apellido, materia) {
    this.id = id;
    this.legajo = legajo;
    this.nombre = nombre;
    this.apellido = apellido;
    this.materia = materia;
  }
}

module.exports = Profesor;

class Estudiante {
  constructor(id, legajo, nombre, apellido, edad, carrera) {
    this.id = id;
    this.legajo = legajo;
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
    this.carrera = carrera;
  }
}

module.exports = Estudiante;

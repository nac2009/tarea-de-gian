const express = require("express");
const router = express.Router();

const estudiantesController = require("../Controllers/estudiantesController.js");

router.get("/listar", estudiantesController.consultar);
router.post("/alta", estudiantesController.ingresar);
router.put("/modificar", estudiantesController.actualizar);
router.delete("/eliminar", estudiantesController.borrar);

module.exports = router;

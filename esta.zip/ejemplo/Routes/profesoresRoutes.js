const express = require("express");
const router = express.Router();

const profesoresController = require("../Controllers/profesoresController.js");

router.get("/listar", profesoresController.consultar);
router.post("/alta", profesoresController.ingresar);
router.put("/modificar", profesoresController.actualizar);
router.delete("/eliminar", profesoresController.borrar);

module.exports = router;

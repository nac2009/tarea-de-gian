const express = require("express");
const cors = require("cors");
const app = express();

const estudiantesRoutes = require("./expresjs/Routes/estudiantesRoutes.js");
const profesoresRoutes = require("./expresjs/Routes/profesoresRoutes.js");

app.use(express.json());
app.use(cors());

// Ruta principal
app.get("/", (req, res) => {
  res.send("Hola Mundo desde Express");
});

app.use("/estudiantes", estudiantesRoutes);
app.use("/profesores", profesoresRoutes);

// Levantar servidor
app.listen(3000, () => {
  console.log("Servidor funcionando en http://localhost:3000");
});

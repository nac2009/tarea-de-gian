// Importamos express para poder crear un "Router": un mini-servidor
// de rutas que despues montamos dentro de server.js.
import express from "express";

// Importamos el controlador de alumnos, que tiene las 4 funciones
// (consultar, ingresar, actualizar, borrar) que van a manejar la logica
// de cada endpoint. Ojo con la extension ".js": es obligatoria en ESM.
import alumnosController from "../controllers/alumnosController.js";

// Creamos una instancia de Router. A partir de aca, "router" funciona
// como un mini "app" de express, pero solo para las rutas de alumnos.
const router = express.Router();

// GET /alumnos/listar
// Cuando llega una peticion GET a esta ruta, express ejecuta
// la funcion "consultar" del controlador (lista todos o uno por ?id=).
router.get("/listar", alumnosController.consultar);

// POST /alumnos/alta
// Cuando llega una peticion POST con datos en el body,
// express ejecuta "ingresar" para crear un alumno nuevo.
router.post("/alta", alumnosController.ingresar);

// PUT /alumnos/modificar
// Cuando llega una peticion PUT con el id y los campos a cambiar
// en el body, express ejecuta "actualizar".
router.put("/modificar", alumnosController.actualizar);

// DELETE /alumnos/eliminar
// Cuando llega una peticion DELETE con el id en el body,
// express ejecuta "borrar" para eliminar ese alumno.
router.delete("/eliminar", alumnosController.borrar);

// Exportamos el router como export default para poder importarlo
// en server.js y montarlo bajo un prefijo, por ejemplo:
// app.use("/alumnos", alumnosRoutes)
export default router;

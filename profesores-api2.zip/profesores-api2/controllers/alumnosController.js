// Importamos el modelo: sigue siendo el único que habla con MySQL.
import AlumnoModel from "../models/AlumnoModel.js";

// Importamos la entidad Alumno: la usamos acá para armar objetos
// antes de guardarlos, y para aprovechar sus métodos
// (validar, esMayorDeEdad) sin repetir esa lógica en el controlador.
import Alumno from "../entities/Alumno.js";

// GET /alumnos/listar
// Devuelve todos los alumnos. Si se pasa ?id=X por query,
// devuelve solamente ese alumno.
const consultar = async (req, res) => {
  try {
    const { id } = req.query;

    if (id) {
      // El modelo ya nos devuelve una instancia de Alumno (o null).
      const alumno = await AlumnoModel.obtenerPorId(id);

      if (!alumno) {
        return res.status(404).json({
          mensaje: `No se encontro un alumno con id ${id}`,
        });
      }

      // res.json llama automáticamente a alumno.toJSON() por dentro,
      // así que "data" sale con la forma que definimos en la entidad.
      // Además aprovechamos el método esMayorDeEdad() de la entidad,
      // como ejemplo de comportamiento propio del objeto.
      return res.json({
        mensaje: "consulta alumno",
        data: alumno,
        mayorDeEdad: alumno.esMayorDeEdad(),
      });
    }

    // obtenerTodos devuelve un array de instancias de Alumno.
    const alumnos = await AlumnoModel.obtenerTodos();

    res.json({
      mensaje: "consulta alumnos",
      data: alumnos,
    });
  } catch (error) {
    res.status(500).json({
      mensaje: "Error al consultar alumnos",
      error: error.message,
    });
  }
};

// POST /alumnos/alta
// Recibe nombre, apellido, edad, curso y carrera por body y crea un alumno nuevo.
const ingresar = async (req, res) => {
  try {
    const { nombre, apellido, edad, curso, carrera } = req.body;

    // Armamos una instancia de Alumno con los datos crudos del body.
    // El id va en null porque todavía no existe en la base de datos.
    const nuevoAlumno = new Alumno(
      null,
      nombre,
      apellido,
      edad,
      curso,
      carrera
    );

    // En vez de validar "a mano" con ifs sueltos en el controlador,
    // le delegamos la validación a la propia entidad. Si algo está
    // mal, alumno.validar() lanza un Error (throw).
    try {
      nuevoAlumno.validar();
    } catch (errorValidacion) {
      // Atajamos específicamente el error de validación acá,
      // para responder 400 (pedido mal formado) en vez de 500.
      return res.status(400).json({
        mensaje: errorValidacion.message,
      });
    }

    // Si la validación pasó, le pedimos al modelo que lo guarde.
    // El modelo devuelve una nueva instancia de Alumno con el id real.
    const alumnoGuardado = await AlumnoModel.crear(nuevoAlumno);

    res.status(201).json({
      mensaje: "ingreso alumno",
      data: alumnoGuardado,
    });
  } catch (error) {
    // Este catch atrapa errores "reales" (de conexión, de la query),
    // distintos del error de validación de arriba.
    res.status(500).json({
      mensaje: "Error al ingresar alumno",
      error: error.message,
    });
  }
};

// PUT /alumnos/modificar
// Recibe id (obligatorio) y los campos que se quieran actualizar por body.
const actualizar = async (req, res) => {
  try {
    const { id, nombre, apellido, edad, curso, carrera } = req.body;

    if (!id) {
      return res.status(400).json({
        mensaje: "el id es obligatorio para modificar un alumno",
      });
    }

    // Traemos el alumno actual como instancia de Alumno.
    const alumnoActual = await AlumnoModel.obtenerPorId(id);

    if (!alumnoActual) {
      return res.status(404).json({
        mensaje: `No se encontro un alumno con id ${id}`,
      });
    }

    // Armamos una NUEVA instancia de Alumno combinando lo que vino
    // en el body con lo que ya había en la base (actualización parcial).
    const alumnoActualizado = new Alumno(
      alumnoActual.id,
      nombre !== undefined ? nombre : alumnoActual.nombre,
      apellido !== undefined ? apellido : alumnoActual.apellido,
      edad !== undefined ? edad : alumnoActual.edad,
      curso !== undefined ? curso : alumnoActual.curso,
      carrera !== undefined ? carrera : alumnoActual.carrera
    );

    // Volvemos a usar la validación de la entidad, para no permitir
    // que una actualización deje nombre/apellido vacíos.
    try {
      alumnoActualizado.validar();
    } catch (errorValidacion) {
      return res.status(400).json({
        mensaje: errorValidacion.message,
      });
    }

    // Le pedimos al modelo que persista los cambios en la base.
    const resultado = await AlumnoModel.actualizar(id, alumnoActualizado);

    res.json({
      mensaje: "modificacion alumnos",
      data: resultado,
    });
  } catch (error) {
    res.status(500).json({
      mensaje: "Error al modificar alumno",
      error: error.message,
    });
  }
};

// DELETE /alumnos/eliminar
// Recibe id por body y elimina ese alumno.
const borrar = async (req, res) => {
  try {
    const { id } = req.body;

    if (!id) {
      return res.status(400).json({
        mensaje: "el id es obligatorio para eliminar un alumno",
      });
    }

    const seElimino = await AlumnoModel.eliminar(id);

    if (!seElimino) {
      return res.status(404).json({
        mensaje: `No se encontro un alumno con id ${id}`,
      });
    }

    res.json({
      mensaje: "eliminacion alumnos",
    });
  } catch (error) {
    res.status(500).json({
      mensaje: "Error al eliminar alumno",
      error: error.message,
    });
  }
};

// Exportamos las 4 funciones del controlador, agrupadas en un objeto.
export default { consultar, ingresar, actualizar, borrar };

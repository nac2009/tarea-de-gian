// Importamos el pool de conexión a MySQL. El modelo sigue siendo
// la única capa que ejecuta SQL.
import pool from "../config/conexion.js";

// Importamos la entidad Alumno: la usamos para "envolver" las filas
// que trae MySQL, en vez de devolver objetos planos sueltos.
import Alumno from "../entities/Alumno.js";

// Función interna (no se exporta) que convierte una fila de MySQL
// (objeto plano: { id_estudiante, nombre, apellido, edad, curso, carrera })
// en una instancia de la clase Alumno. La reutilizamos en varios métodos
// para no repetir el mismo "new Alumno(...)" en cada uno.
const filaAAlumno = (fila) =>
  new Alumno(
    fila.id_estudiante,
    fila.nombre,
    fila.apellido,
    fila.edad,
    fila.curso,
    fila.carrera
  );

// obtenerTodos: trae todos los registros y los devuelve como
// instancias de Alumno (no como filas crudas de MySQL).
const obtenerTodos = async () => {
  const [rows] = await pool.query("SELECT * FROM estudiantes");

  // rows.map(...) recorre cada fila y la transforma en un Alumno,
  // devolviendo un array de instancias de la clase.
  return rows.map(filaAAlumno);
};

// obtenerPorId: busca un único alumno y lo devuelve como
// instancia de Alumno, o null si no existe.
const obtenerPorId = async (id) => {
  const [rows] = await pool.query(
    "SELECT * FROM estudiantes WHERE id_estudiante = ?",
    [id]
  );

  // Si no hay filas, no hay nada que envolver: devolvemos null.
  if (rows.length === 0) return null;

  // Si hay una fila, la convertimos en instancia de Alumno.
  return filaAAlumno(rows[0]);
};

// crear: recibe una instancia de Alumno YA VALIDADA
// (el controlador llama a alumno.validar() antes de pasarla acá),
// la inserta en la base y devuelve una nueva instancia con el id real.
const crear = async (alumno) => {
  // Sacamos los atributos de la instancia para armar el INSERT.
  const { nombre, apellido, edad, curso, carrera } = alumno;

  const [result] = await pool.query(
    "INSERT INTO estudiantes (nombre, apellido, edad, curso, carrera) VALUES (?, ?, ?, ?, ?)",
    [nombre, apellido, edad, curso, carrera]
  );

  // Devolvemos una nueva instancia de Alumno, ahora con el id
  // que le asignó MySQL automáticamente (result.insertId).
  return new Alumno(result.insertId, nombre, apellido, edad, curso, carrera);
};

// actualizar: recibe el id y una instancia de Alumno con los
// valores finales (ya combinados entre lo nuevo y lo existente).
const actualizar = async (id, alumno) => {
  const { nombre, apellido, edad, curso, carrera } = alumno;

  await pool.query(
    "UPDATE estudiantes SET nombre = ?, apellido = ?, edad = ?, curso = ?, carrera = ? WHERE id_estudiante = ?",
    [nombre, apellido, edad, curso, carrera, id]
  );

  // Devolvemos una instancia de Alumno representando el estado
  // final del registro, para que el controlador la mande al cliente.
  return new Alumno(Number(id), nombre, apellido, edad, curso, carrera);
};

// eliminar: borra un alumno según su id. No necesita trabajar
// con la entidad, porque no devuelve datos del alumno, solo
// si se pudo borrar o no.
const eliminar = async (id) => {
  const [result] = await pool.query(
    "DELETE FROM estudiantes WHERE id_estudiante = ?",
    [id]
  );

  return result.affectedRows > 0;
};

// Exportamos las 5 funciones del modelo agrupadas en un objeto.
export default { obtenerTodos, obtenerPorId, crear, actualizar, eliminar };

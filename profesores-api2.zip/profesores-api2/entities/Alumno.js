// La clase Alumno define la "forma" de un alumno: qué atributos
// tiene y qué reglas propias le corresponden (validación, cálculos).
// Al igual que Profesor, esta clase NO sabe nada de SQL ni de la
// base de datos — solo conoce sus propios datos.
class Alumno {
  // El constructor recibe los datos crudos y los guarda como
  // atributos de la instancia. "id" puede venir null cuando
  // todavía no fue guardado en la base (antes del INSERT).
  constructor(id, nombre, apellido, edad, curso, carrera) {
    this.id = id;
    this.nombre = nombre;
    this.apellido = apellido;
    this.edad = edad;
    this.curso = curso;
    this.carrera = carrera;
  }

  // Getter: se puede usar como propiedad (alumno.nombreCompleto),
  // sin paréntesis, aunque por dentro sea una función.
  get nombreCompleto() {
    return `${this.nombre} ${this.apellido}`;
  }

  // Método que encapsula la regla de negocio "cuándo un alumno
  // es mayor de edad". Vive junto con los datos que la definen (this.edad).
  esMayorDeEdad() {
    return this.edad !== undefined && this.edad !== null && this.edad >= 18;
  }

  // Método de validación: chequea que los campos obligatorios
  // estén presentes. Lanza un error (throw) para cortar la ejecución
  // apenas algo está mal. Quien llame a este método debe rodearlo
  // con try/catch.
  validar() {
    if (!this.nombre || !this.apellido) {
      throw new Error("nombre y apellido son obligatorios");
    }
  }

  // toJSON: método especial que JavaScript llama automáticamente
  // cuando hacés JSON.stringify(alumno) (por ejemplo, dentro de
  // res.json(alumno)). Acá controlamos exactamente qué forma tiene
  // el objeto que se manda al cliente.
  toJSON() {
    return {
      id: this.id,
      nombre: this.nombre,
      apellido: this.apellido,
      edad: this.edad,
      curso: this.curso,
      carrera: this.carrera,
    };
  }
}

// Exportamos la clase como export default, para poder importarla
// con el nombre que queramos en otros archivos.
export default Alumno;
